# Welcome plugin

Display a welcome message for members that have joined the server!

## Configuration

* Welcome message - Self-explanatory. Bot will send this message when some user join your server.
  {user} refers to the new member, {server} to your server name.  
  `{user}, welcome to {server}!` => `@Morty, welcome to Mee6 server!`
  * Send in Private Message - Send welcome message to DM instead of welcome channel.
* Good Bye message - Self-explanatory. Bot will send this message when some user join your server.
  {user} refers to the leaving member, {server} to your server name.
* Enabled - goodbye message can be disabled
* Welcome/Good-Bye channel - channel for sending welcome/goodbye messages.
