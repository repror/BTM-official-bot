# Search Anything plugin

TODO
