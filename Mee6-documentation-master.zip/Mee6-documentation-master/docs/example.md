# example of a page

## subheader 2

### subheader 3

some random text
Lorem ipsum dolor sit amet, **consectetur adipiscing elit. Pellentesque feugiat luctus ornare.** *Cras in eleifend lectus. Integer tempus, nunc id porttitor sagittis,* felis erat fringilla urna, non faucibus eros justo porttitor tortor. Etiam eget massa in elit egestas ultrices. Sed suscipit tellus sed augue faucibus, vitae laoreet diam commodo. Cras porta gravida metus, vitae vulputate libero pulvinar non. Integer dignissim, sem ultrices commodo pretium, erat velit tincidunt metus, id tristique nisi turpis at lorem.

## another header

**bold text** and *italic text*

[a link](https://github.com/SilBoydens) to my github

and much more possible, it is in markdown!!

[markdown cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)

[a cool editor](https://stackedit.io/editor#)
