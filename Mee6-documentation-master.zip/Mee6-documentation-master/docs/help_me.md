# Help Me! plugin

Shows commands for Mee6 on current server.

## Configuration

* Send the !help in Private Message - If enabled, Mee6 sends to PM/DM instead of channel.
